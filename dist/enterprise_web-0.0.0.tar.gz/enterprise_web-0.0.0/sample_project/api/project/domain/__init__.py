from .project_entity import ProjectEntity

entities = [ProjectEntity]
