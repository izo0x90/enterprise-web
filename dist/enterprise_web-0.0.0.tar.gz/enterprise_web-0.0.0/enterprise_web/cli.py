def main():
    print('Running CLI')

if __name__ == '__main__':
    main()
